import './App.css'; 
import {useState} from "react";

function App() {
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");

  const [bmiResult, setBmiResult] = useState(null);

  const [status, setStatus] = useState("");

  function calculateBMI() {
    let bmi = Number(weight / (height / 100) ** 2).toFixed(2);
    setBmiResult(bmi);

    let bmiStatus = getStatus(bmi);

    setStatus(bmiStatus);

    setHeight("");
    setWeight("");
  }

  function getStatus(bmi) {
    if (bmi < 18.5) return "You are in Underweight range";
    else if (bmi >= 18.5 && bmi < 24.9) return "You are in Healthy weight range";
    else if (bmi >= 25 && bmi < 29.9) return "You are in overweight range";
    else return "Obese";
  }
  return (
    <>
    <div className="bmi">
      <div className="title">BMI CALCULATOR</div>
    <form>
  <div className="mb-3">
    <label for="height" className="form-label">Enter your height in cm:</label>
    <input 
    type="email" 
    className="form-control" 
    placeholder='Enter your Height'
    id="height"
    value={height}
    onChange={(e) => setHeight(e.target.value)}
    />
  </div>
  <div className="mb-3">
    <label for="weight" className="form-label">Enter your weight in kg:</label>
    <input 
    type="text" 
    className="form-control"
     id="weight"
     placeholder='Enter your Weight'
     value={weight}
     onChange={(e)=> setWeight(e.target.value)}
     />
  </div>
 
  <button 
  type="button" 
  className="btn btn-primary"
  onClick={calculateBMI}
  >Submit</button>

{bmiResult && (
          <div className="mt-4">
            <p>Your BMI is: {bmiResult} </p>
            <p>{status}</p>
          </div>
        )}
</form>
  
    </div>
    </>
  );
}

export default App;
